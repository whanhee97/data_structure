var searchData=
[
  ['m_5fid',['m_Id',['../class_item_type.html#a8901a6a0f86149c6f24f4cc56251d58a',1,'ItemType']]],
  ['m_5fsaddress',['m_sAddress',['../class_item_type.html#ac20363f89c5a8aa0fa3349921994c34e',1,'ItemType']]],
  ['m_5fsname',['m_sName',['../class_item_type.html#a360e90ab637b2463cf8fae3563612316',1,'ItemType']]],
  ['makeempty',['MakeEmpty',['../class_application.html#ad721de0f33093a666e34681eb20bf2bf',1,'Application::MakeEmpty()'],['../class_linked_list.html#a544d6cfa144857d563e977420f80b383',1,'LinkedList::MakeEmpty()']]]
];
