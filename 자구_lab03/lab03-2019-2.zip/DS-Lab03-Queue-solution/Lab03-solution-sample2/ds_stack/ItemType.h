/**
*	@breif	Typedef for stack testing simply.
*/
typedef char ItemType;